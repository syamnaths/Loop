# Loop

Loop is a local-first framework for building software with an AI agent and a human owner. From version 0.4 it is **atlas-first**: every project starts from a flow atlas, every feature is built to its map, and a feature is done only when its map is flipped to delivered with real source references.

Loop is **platform-independent**. You choose the platform at the start: web, Android, iPhone/iPad, mobile for both (Flutter, React Native…), desktop, backend/API, command-line/library, other, or several together. The choice shapes the proof ladder, platform rules, version bumps and the release map. The atlas tools need Node 18+ on your machine only.

## Start a new project

**Easiest:** make an empty folder, open it in your agent and say **"Use Loop for this project."** Loop asks a few short questions in one message (name, who it is for, first release, platform, stack, languages, features, template page), then sets up the project and starts building the first feature by itself.

**If you like to fill a form first:**

1. Copy `start/START.md` into the empty project folder and fill it in. It is plain text with help lines.
2. Have a basic template page (an HTML page, screenshot, Figma export or folder)? Copy `start/template-page/` next to it and put your files inside. Every screen will follow it.
3. Say **"Use Loop for this project."** Loop reads the file, asks only what is missing, and starts building.

**From the terminal:**

```
node scripts/loop-init.mjs ~/Desktop/Ikigai/my-app --git            # reads my-app/START.md, or asks the questions
node scripts/loop-init.mjs ~/Desktop/Ikigai/my-app --git --start    # then opens your agent (LOOP_AGENT, default codex) to build
node scripts/loop-init.mjs ~/Desktop/Ikigai/my-app --brief my-brief.json --platform android
```

JSON briefs still work (see `examples/`). Open `my-app/docs/app-map/index.html` to see the plan: the whole product, the build order, a map per feature (all `planned`), the quality loop and the release path for your platform.

What the starter creates:

| Path | Purpose |
| --- | --- |
| `AGENTS.md` | Working agreement every agent reads first |
| `HANDOFF.md` | One `CURRENT RESUME` block: status and the exact next action |
| `.loop/workflow.md`, `.loop/tracks/<map>/spec.md` | Delivery path, modes, and a done-checklist per feature and for release |
| `.loop/platform.md` | Chosen platform: stack, test commands, proof ladder, rules, release path |
| `docs/app-map/` | Atlas data, builder, status, atlas check, interactive `index.html`, fix queue |
| `docs/project-brief.md`, `docs/START.md` | The brief, your answers and open questions |
| `design/template-page/` | Your basic template page, when given. Every screen follows it. |
| `Loop/` | Project copy of the policy files |
| `package.json` (JavaScript projects only) | `npm run atlas`, `atlas:status`, `atlas:next`, `atlas:check`, `atlas:verify`. Other platforms use `node docs/app-map/...` directly. |

## Add Loop to an existing project

```
node scripts/loop-init.mjs ~/Desktop/Ikigai/existing-app --adopt --name "Existing App" --platform android
```

Without `--platform`, Loop guesses from the files and tells you. Adds the atlas tools, policy copy, tracks and platform notes. **Nothing existing is overwritten.** Then map the current behaviour as delivered maps before planning new features.

## Files in this folder

| File | What it is |
| --- | --- |
| `loop.md` | The core policy (v0.4) |
| `ATLAS-FIRST.md` | Atlas format and the build loop |
| `OWNER-COMMUNICATION.md` | How to talk to the owner |
| `EFFICIENT-WORKFLOW.md` | Bounded context, modes, cost honesty |
| `DELIVERY-WORKFLOW.md` | Tracks, reviews, debugging, release |
| `SECURITY.md` | Security verification standard |
| `MODEL-ROUTING.md`, `LOCAL-MODEL-ROUTING.md`, `config/`, `scripts/codex_model_router.py` | Optional model routing |
| `start/START.md`, `start/template-page/` | The fill-in form and the folder for your basic template page |
| `scripts/loop-init.mjs`, `starter/` | The atlas-first project starter (`starter/platforms.mjs` holds the platform profiles) |
| `examples/` | Example briefs for a web app and an Android app |
| `tests/` | Checks for the router, policy wiring and the starter |
| `archive/v0.3.1/` | The previous versions of changed files |
| `CHANGELOG.md` | What changed in each version |

## Check Loop itself

```
node --test tests/test_loop_init.mjs
python3 -m unittest tests/test_codex_model_router.py tests/test_efficiency_contract.py
```

Install as a Codex plugin: see `INSTALL.md`.
