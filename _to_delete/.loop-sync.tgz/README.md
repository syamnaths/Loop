# Loop

Loop is a local-first framework for building software with an AI agent and a human owner. From version 0.4 it is **atlas-first**: every project starts from a flow atlas, every feature is built to its map, and a feature is done only when its map is flipped to delivered with real source references.

## Start a new project

1. Write a brief (copy `examples/brief.example.json`): name, who it is for, what the first release must do, stack, languages, and the features with their steps.
2. Run:

   ```
   node scripts/loop-init.mjs ~/Desktop/Ikigai/my-app --brief my-brief.json --git
   ```

   Without `--brief`, the script asks the questions in the terminal.
3. Open `my-app/docs/app-map/index.html`. You will see the whole product, the build order, a map per feature (all `planned`) and the quality loop.
4. In the new project, tell your agent: **"Use Loop for this project. Build the next atlas map."**

What the starter creates:

| Path | Purpose |
| --- | --- |
| `AGENTS.md` | Working agreement every agent reads first |
| `HANDOFF.md` | One `CURRENT RESUME` block: status and the exact next action |
| `.loop/workflow.md`, `.loop/tracks/<feature>/spec.md` | Delivery path, modes, and a done-checklist per feature |
| `docs/app-map/` | Atlas data, builder, status, browser check, interactive `index.html`, fix queue |
| `docs/project-brief.md` | The approved brief and open questions |
| `tests/atlas-contract.test.mjs` | Atlas builds, tracks exist, delivered maps have source, build order is complete |
| `Loop/` | Project copy of the policy files |
| `package.json` | `npm run atlas`, `atlas:status`, `atlas:next`, `atlas:verify`, `test` |

## Add Loop to an existing project

```
node scripts/loop-init.mjs ~/Desktop/Ikigai/existing-app --adopt --name "Existing App"
```

Adds the atlas tools, policy copy, tracks and scripts. **Nothing existing is overwritten.** Then map the current behaviour as delivered maps before planning new features.

## Files in this folder

| File | What it is |
| --- | --- |
| `loop.md` | The core policy (v0.4) |
| `ATLAS-FIRST.md` | Atlas format and the build loop |
| `OWNER-COMMUNICATION.md` | How to talk to the owner |
| `EFFICIENT-WORKFLOW.md` | Bounded context, modes, cost honesty |
| `DELIVERY-WORKFLOW.md` | Tracks, reviews, debugging, release |
| `SECURITY.md` | Security verification standard |
| `MODEL-ROUTING.md`, `LOCAL-MODEL-ROUTING.md`, `config/`, `scripts/codex_model_router.py` | Optional model routing |
| `scripts/loop-init.mjs`, `starter/` | The atlas-first project starter |
| `examples/brief.example.json` | A complete example brief |
| `tests/` | Checks for the router, policy wiring and the starter |
| `archive/v0.3.1/` | The previous versions of changed files |
| `CHANGELOG.md` | What changed in each version |

## Check Loop itself

```
node --test tests/test_loop_init.mjs
python3 -m unittest tests/test_codex_model_router.py tests/test_efficiency_contract.py
```

Install as a Codex plugin: see `INSTALL.md`.
