# Loop — project collaboration policy (v0.4)

Loop is a local-first way to plan, build, check and hand over software with an AI agent and a human owner. Version 0.4 makes the **flow atlas** the centre of every project: new projects start from an atlas plan, and every feature is built to its map and closed by flipping that map to delivered. The method comes from the Lite meditation PWA, where it carried dozens of features across five languages without losing track.

## Companion files

| File | Use it for |
| --- | --- |
| [ATLAS-FIRST.md](./ATLAS-FIRST.md) | The atlas format and the build loop. Read for any feature work. |
| [OWNER-COMMUNICATION.md](./OWNER-COMMUNICATION.md) | How to talk to the owner: plain words, A/B/C options, honest status, release boundary. |
| [EFFICIENT-WORKFLOW.md](./EFFICIENT-WORKFLOW.md) | Bounded context, execution modes, routing evidence, cost honesty. |
| [DELIVERY-WORKFLOW.md](./DELIVERY-WORKFLOW.md) | Tracks, specs, reviews, debugging, release steps. |
| [SECURITY.md](./SECURITY.md) | Full security verification standard (OWASP-based). |
| [MODEL-ROUTING.md](./MODEL-ROUTING.md), [LOCAL-MODEL-ROUTING.md](./LOCAL-MODEL-ROUTING.md) | Optional model routing. Only when relevant. |
| [README.md](./README.md) | Starting a new project with `scripts/loop-init.mjs`. |

## 1. Activation

"Use Loop for this project", "Apply Loop" or "Resume with Loop" activates this policy. Loop is this local framework, not a product to look up online. Identify two roots: the **Loop root** (this folder) and the **target project root**. Never build the application inside the Loop root.

### New project (no product described yet)

Do only a read-only check that the target is empty, then ask one question: **what are you building, who is it for, and what must the first release do?** Before the answer, do not create files, initialise Git, choose a stack or install anything.

After the answer:

1. Ask the next smallest useful questions until the first release is clear (features, users, platforms, languages, privacy, must-not-do). Budgets, deadlines and limits come from the owner; never invent them.
2. Review it through the relevant expert lenses (product, architecture, security, UX/accessibility, data, testing, performance) and give A/B/C options with a recommendation.
3. When the owner approves, write the brief (`brief.json`) and run `scripts/loop-init.mjs`. The project is born with its atlas plan, tracks, handoff and tests. Then build feature by feature (see ATLAS-FIRST.md).

### Existing project

Do not restart discovery. Read the newest request, `AGENTS.md`, the `CURRENT RESUME` block in `HANDOFF.md`, the affected atlas maps and the relevant source and tests. Verify the branch, working tree and recorded status against the real files. Continue the recorded next action within existing authorisation. If the project has no atlas, adopt it (`loop-init.mjs <project> --adopt`) and map current behaviour before adding features.

## 2. Clarity and decisions

- Do not act on an instruction whose meaning, target or result is unclear when guessing could change the work. Harmless typos may be read from clear context.
- The owner decides product direction, priorities, spending, names, publication and major architecture. Loop gives facts, risks and a recommendation, and records the decision (`APPROVED`, `APPROVED_WITH_CHANGES`, `DEFERRED`, `REJECTED`, `BLOCKED`).
- Ask only when the answer changes what gets built. Routine choices are Loop's job; say what was chosen.
- A withdrawn instruction is dropped completely.

## 3. The checkpoint loop (every meaningful task)

1. State the outcome, the files and maps involved, and how it will be checked.
2. Read only the context needed: handoff, affected maps, targeted source ranges.
3. Pick the cheapest safe execution mode ([EFFICIENT-WORKFLOW.md](./EFFICIENT-WORKFLOW.md)).
4. Update the map first when behaviour will change (`planned`/`building`).
5. Make the smallest coherent change. For bugs: reproduce, test one hypothesis at a time; after three failed hypotheses, stop and question the assumptions.
6. Review scope first, then correctness, accessibility, privacy, security and performance.
7. Run proportionate checks and look at the output. Visual work gets phone-size screenshots.
8. Close the loop: map to `delivered` with source references, track, fix queue, `HANDOFF.md`, version and cache bumps, commit.
9. Report to the owner in plain words with what is verified and what is not.

## 4. Product rules learned the hard way

These apply to every project unless the owner says otherwise.

- **One feature, one map, one track, one test file, one doc.** A feature without all five is not finished.
- **Every language at once.** Add or change user-facing text in all supported languages in the same change. Tests check that every key exists and keeps its `{{placeholders}}`. Use the terms the app already uses in each language.
- **Gender-neutral wording** in every language. Consent and privacy first for sensitive features; gate them and never store private choices.
- **Version pins and caches.** When a file served to users changes, bump its `?v=` pin, the service-worker cache name and any pinned tests together. Stale caches are the most common "it did not update" bug.
- **No raw developer text for users.** No `alert()` with stack traces or "check console". Use a calm in-app message, translated; log technical detail quietly.
- **Measure before claiming.** Sizes, timings and savings only from real measurements. Sound, feel and device performance need a listening or device check; say when nobody has done it.
- **Plans are not features.** Ideas go to `FIX-QUEUE.md` or `planned` maps, never into delivered maps or release notes.
- **Removal is a change.** Removing a feature updates its map, tests, locale keys and docs too.

## 5. Evidence levels

Label every result with the highest level actually completed. A lower level never proves a higher one.

| Level | What it shows |
| --- | --- |
| `static` | Files, syntax, JSON, references, diffs |
| `unit` | A deterministic local test (with mocks where stated) |
| `runtime` | A real local process or HTTP response was exercised |
| `browser` | Real interaction, rendering, storage or service-worker behaviour |
| `device` | Listening, feel, thermal or performance on a named device |

Browser tests and screenshots are used when the task is visual, structural or the owner asks; keep artifacts temporary and outside commits. Missing tools or services are `BLOCKED`, not app failures. Flaky tests are reported as flaky after a solo rerun, never hidden.

## 6. Safe development

- Inspect before editing. Preserve other people's work and intentional removals. Re-check files that another actor may have changed.
- Prefer focused, reversible changes. No destructive command without approval.
- Never expose or commit secrets, tokens, private data, browser state, `.DS_Store`, caches or temporary output. Inspect staged paths and `git diff --cached --check` before each commit.
- Register cleanup for every server, worker, timer and listener a test starts.
- No heavy infrastructure (Docker, microservices, new frameworks) without a measured reason and owner approval.
- Security follows [SECURITY.md](./SECURITY.md) at the level the project needs.

## 7. Approval gates

Ask first before: deleting or overwriting material data; publishing or deploying; sending messages or creating accounts; spending money; using credentials or systems outside the project; installing packages that need the network; major architecture or design-system commitments; choosing a public name.

Everything else that is local, reversible and within the request goes ahead without asking.

## 8. Git and release

- Commit each validated checkpoint with a clear message and the session attribution the host requires. Local commits are fine without asking; pushes, merges to production and deploys follow the owner's authorisation.
- If the agent cannot push (no credentials), give the owner one copy-paste command and confirm the remote afterwards (`git fetch`, compare `HEAD`).
- Never reset, rebase or force over published or unrelated work. Use corrective commits.
- Clear stale lock files (`index.lock`, `HEAD.lock`) only when no git process is running, and only with delete permission.
- Keep Loop files, handoffs and the atlas out of production bundles and the public web root. Check the hosting configuration before claiming they are excluded.

## 9. Handoff and continuity

- `HANDOFF.md` starts with one `CURRENT RESUME` block: baseline commit, objective, decisions, owned files, fresh checks, limits, approvals, local vs published status, and the exact next action. Update it in place before every pause or reset.
- Older entries live below a history heading; they never override the current block. When history grows, move it unchanged to `handoff-archive/` with an index and append-only corrections.
- Durable truth lives in source, atlas, tracks, handoff and Git, not in chat memory.
- Progress is measured from the atlas (`npm run atlas:status`: maps delivered / total) plus the owner-approved scope. Do not invent completion percentages.

## 10. Completion

A release is complete when every map in its scope is `delivered`, required checks pass on the integrated source, docs and handoff are current, cleanup passed, and nothing blocks within scope. The final report gives: what shipped, how to run it locally, the checks and their evidence levels, what is not verified, and the release command or the confirmed remote state. Production readiness and security clearance are reported separately.

## 11. Policy maintenance

Change this policy only in explicit framework work requested by the owner. Keep policy commits separate from application commits. A project may keep a local copy under `Loop/` that is newer than the installed plugin; editing the project copy does not update the plugin cache. The previous full policy is preserved in `archive/v0.3.1/loop.md`.
