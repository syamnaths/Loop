# {{name}} — handoff

## CURRENT RESUME

- **Baseline:** project created by `loop-init.mjs` on {{date}} (Loop {{loopVersion}}). {{gitLine}}
- **Objective (first release):** {{outcome}}
- **For:** {{audience}}
- **Stack:** {{stack}}
- **Languages:** {{languages}}
- **Atlas:** {{mapCount}} maps planned in `docs/app-map/atlas-data.mjs`. Open `docs/app-map/index.html`.
- **Decisions approved:** brief in `docs/project-brief.md`. Open questions are listed there.
- **Checks:** `npm run atlas` and `npm test` passed at creation (static + unit).
- **Status:** nothing built yet. Nothing published.
- **Next action:** run `npm run atlas:next`, then build **{{firstFeature}}** following its map and `.loop/tracks/{{firstFeatureId}}/spec.md`.

## History

- {{date}} — Project created from the approved brief. Atlas plan, tracks and checks generated.
