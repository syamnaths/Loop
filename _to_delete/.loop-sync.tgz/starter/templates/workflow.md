# {{name}} — delivery workflow

Status: default for all work in this project. Policy: `Loop/loop.md`; method: `Loop/ATLAS-FIRST.md`.

## Delivery path

```text
next planned map (npm run atlas:next)
  -> make the map exact, status: building
  -> compact task packet (objective, files, map, acceptance checks)
  -> branch or worktree when the change is substantial or risky
  -> build to the map with behaviour tests
  -> scope review, then quality / risk review
  -> map delivered with source refs, track + fix queue + handoff updated
  -> validated checkpoint commit
  -> owner-approved push / release
```

## Automatic execution modes

| Mode | When | How |
|---|---|---|
| Caveman | Tiny, clear, low-risk edit with a deterministic check | One agent, minimal files, no branch, smallest check. |
| Focused | Small bounded change or bug | One agent, targeted source and tests. |
| Isolated | Feature, refactor, performance, persistence, localisation, broad visual work | Branch/worktree, checkpoint loop, two-stage review, atlas + handoff update. |
| Specialists | Two or more truly independent subtasks | Smallest number of short-lived helpers; one owner integrates. |
| High-risk gate | Publish, migration, auth/secrets, destructive recovery | Prepare and validate, then stop for owner approval. |

Escalate when scope grows; de-escalate only at a clean checkpoint.

## Shared hotspots (one owner at a time)

`docs/app-map/`, app shell / entry files, service worker and cache names, shared translations, settings schema, shared engines.

## Done means

- Map `delivered` with real `source` refs; `npm run atlas` passes.
- Behaviour tests added and passing; `npm test` passes.
- All languages updated; version pins and caches bumped where needed.
- Track checklist ticked; `FIX-QUEUE.md` and `HANDOFF.md` current.
- Owner shown the result (screenshots for visual work) with verified vs not verified stated.
