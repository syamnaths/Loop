---
name: loop
description: "Use when the user says 'Use Loop for this project', 'Apply Loop', 'Resume with Loop', 'Build the next atlas map', or asks for Loop project orchestration. Starts new projects atlas-first with loop-init.mjs, adopts existing projects, builds one atlas map at a time with proof, and keeps a single CURRENT RESUME handoff."
---

# Loop orchestration (v0.4, atlas-first)

Apply `loop.md` from the project-local `Loop/` folder when present, otherwise from the plugin root. Companion files: `ATLAS-FIRST.md` (atlas format and build loop), `OWNER-COMMUNICATION.md`, `EFFICIENT-WORKFLOW.md`, `DELIVERY-WORKFLOW.md`, `SECURITY.md`, `MODEL-ROUTING.md`. The project copy may be newer than the installed plugin; do not edit the installed cache.

## Invocation

An explicit request to use or resume **Loop** selects this skill immediately. Loop is this local workflow, not an OpenAI product term: do not open OpenAI Docs or search the web to identify it. Never ask the user to pick a task class; infer it.

If the prompt contains `[LOOP_ROUTED_CHILD]`, this is already a routed bounded task: do not classify or dispatch again. Do only that task, validate it, and return.

## New project (empty folder or new idea)

1. Ask one short question: what are we building, for whom, and what must the first release do. Do nothing else first: no Git, installs, architecture or files.
2. Turn the answer into a brief (name, audience, outcome, stack, languages, features with steps, optional failure path and release). Show it in plain words, list open questions, and get the owner's approval. Never invent budgets, deadlines or constraints.
3. Save the approved brief as JSON and run, from the Loop root:

   ```
   node scripts/loop-init.mjs <target-folder> --brief <brief.json> --git
   ```

   This creates `AGENTS.md`, `HANDOFF.md` (one CURRENT RESUME block), `.loop/workflow.md`, one track per feature, `docs/app-map/` (atlas data, builder, status, browser check, `index.html`), atlas contract tests and `package.json` scripts. All feature maps start `planned`.
4. Open the atlas, show the owner the overview and build order, then begin the build loop.

## Existing project

Read `AGENTS.md`, `HANDOFF.md` (CURRENT RESUME only), then `npm run atlas:status`. If the project has no atlas yet, run `node scripts/loop-init.mjs <project> --adopt --name "<Name>"` (it never overwrites files), then map current behaviour as `delivered` maps with real `file:line` sources before planning new work. Preserve unrelated changes; reconcile docs with code.

## Build loop (one map at a time)

1. `npm run atlas:next` → the next map in `meta.buildOrder` and its track.
2. Confirm the map's steps are still right; edit the map first if not (`planned` → `building`).
3. Build only that map's behaviour. Add or update a test that proves it.
4. Prove at the strongest evidence level available (static, unit, runtime, browser, device). Say which level you reached.
5. Flip the map to `delivered` with real `file:line` sources. `npm run atlas` refuses fake or missing sources.
6. Run `npm test`, update the CURRENT RESUME block (progress from `atlas:status`), commit with a checkpoint id.
7. Report to the owner in plain words with a screenshot when visual, then repeat.

Release, push, spending, data deletion and user-visible content changes stay behind the approval gates in `loop.md`. When the owner must push, give one copy-paste command and confirm with `git fetch` afterwards.

## Routing

Use local context first (handoff, atlas, the track, the real source). Route bounded subtasks to the least-cost healthy model that meets the need. With Codex CLI 0.148.0+, use `scripts/codex_model_router.py`; it reads only the `[LOOP_CLASSIFY]` … `[/LOOP_CLASSIFY]` slice for classification when present, applies per-run model overrides, and never rewrites global config. If automatic switching is unavailable, recommend a model, keep a resumable checkpoint, and ask the engineer to switch with the host selector (for example `/model`). Never claim a switch you did not see.

## Boundaries

Playwright and screenshots are used when the change is visual or the owner asks, through `npm run atlas:verify` or project tests. Destructive or history-changing recovery needs approval. The skill orchestrates; the project's source, tests, atlas and handoff are the record.
