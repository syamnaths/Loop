# Atlas-first delivery

Loop builds every project from a **flow atlas**: a set of small, connected maps that show how the product behaves. The atlas is written **before** code, updated **with** every change, and checked **by machine**. This method was proven on the Lite meditation PWA (51 maps, 435 steps, 5 languages, dozens of features) and is now the default for every Loop project.

## Why

- The owner can see the whole product on one page, without reading code.
- Every session starts from the same picture, so nothing is rebuilt by mistake and nothing is forgotten.
- A feature is not "done" until its map says so, and the map cannot say so without real source references.
- Plans and delivered behaviour never mix: plans live as `planned` maps or in `FIX-QUEUE.md`.

## The atlas files (in every project)

| File | Purpose |
| --- | --- |
| `docs/app-map/atlas-data.mjs` | The only file people edit. Exports `meta` and `graphs`. |
| `docs/app-map/build-atlas.mjs` | Validates every map and writes the outputs below. Fails on broken edges, unknown drilldowns, missing source files or out-of-range lines. |
| `docs/app-map/atlas-status.mjs` | Shows planned / building / delivered, the next map to build and drift issues. `--next` prints the steps to build. |
| `docs/app-map/verify-atlas.mjs` | Optional browser check (Playwright): counts, selection, label fit, keyboard, phone width, print, SVG export. |
| `docs/app-map/index.html` | Generated interactive atlas. Open it in a browser. |
| `docs/app-map/FLOW-REFERENCE.md`, `atlas.json` | Generated text + Mermaid reference and machine copy. |
| `docs/app-map/FIX-QUEUE.md` | Proposed and completed fixes. Plans never go into delivered maps. |

## Map format

```js
graphs.push({
  id: 'checkout',                 // unique, also the track folder name
  group: 'Features',              // Start here | Features | Systems | Supporting pages (meta.groups can change this)
  title: 'Checkout',
  subtitle: 'From cart to paid order.',
  status: 'planned',              // planned → building → delivered
  source: 'src/checkout.js:1; tests/checkout.test.mjs:1', // required unless planned
  rows: [                         // each row is drawn left-to-right, rows top-to-bottom
    [['cart', 'Review cart', 'Items, totals and edit links.']],
    [['pay', 'Pay', 'Card form; errors shown in plain words.'], ['fail', 'Payment fails', 'Keep the cart; offer retry.']],
    [['done', 'Order placed', 'Receipt screen and email.']]
  ],
  edges: [['cart', 'pay', 'Continue'], ['pay', 'done', 'Approved'], ['pay', 'fail', 'Declined'], ['fail', 'pay', 'Retry']],
  drilldowns: { pay: 'payments' },// optional: open another map from a step
  notes: ['Prices come from the server; the client never sets them.']
});
```

Write every step as the user experiences it, with the real guard, default, exit and failure path. Short labels, specific details.

## The build loop

1. **Init.** `node <Loop>/scripts/loop-init.mjs <project> --brief brief.json` creates the project, the atlas (an overview, a roadmap, a quality-gates map and one `planned` map per feature), a track per feature, `AGENTS.md`, `HANDOFF.md` and tests. It builds the atlas and prints the first feature to build.
2. **Pick.** `npm run atlas:next` names the next map in `meta.buildOrder` that is not delivered, with its steps and track.
3. **Plan the map first.** Before code, make the map exact: steps, branches, failure paths, defaults. Show it to the owner when a product decision is open. Set `status: 'building'`.
4. **Build to the map.** Implement step by step. Add tests that check behaviour, not wording.
5. **Prove it.** Run the tests, `npm run atlas`, and the browser check when the change is visual or structural. Take screenshots when the owner will judge by eye.
6. **Flip the map.** Add `source` references (`file:line`), set `status: 'delivered'`, update notes with the evidence you actually have. The build refuses a delivered map without real source.
7. **Record.** Update the track, `FIX-QUEUE.md` (if a tracked fix), `meta.commit`/`meta.date`/`meta.scope`, and the `CURRENT RESUME` block in `HANDOFF.md`.
8. **Repeat** from step 2. When every map is delivered, add the next feature as a new `planned` map.

## Rules that keep the atlas honest

- A behaviour change and its map change land in the **same** commit.
- If source and map disagree, read the source, fix whichever is wrong, and say so.
- Never mark `delivered` from a plan, a mock or a passing wording test. Notes must say which evidence exists: source review, unit test, browser test, device check.
- Do not invent flows to have something to draw. A non-flow change only needs a check that the atlas is still accurate.
- When a feature is removed, remove or rewrite its map, and say "removed (owner: reason)" in notes so history is clear.
- Keep the atlas a development tool: never precache or ship it inside the product bundle.

## Existing projects

For a project that has no atlas, start with `loop-init.mjs <project> --adopt`: it adds the atlas tools and an empty `atlas-data.mjs` without touching other files. Then map the current behaviour as `delivered` maps (with source references) before planning new features as `planned` maps.
