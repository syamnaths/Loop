#!/usr/bin/env node
// Loop project starter (atlas-first). Creates a new project whose first
// artefact is its flow atlas: an overview, a roadmap, a quality-gates map and
// one planned map per feature, plus tracks, AGENTS.md, HANDOFF.md, tests and
// npm scripts. Then it builds the atlas and prints the first feature to build.
//
//   node scripts/loop-init.mjs <target> --brief brief.json [--git]
//   node scripts/loop-init.mjs <target>                      (asks questions)
//   node scripts/loop-init.mjs <existing-project> --adopt   (adds atlas tools only)
//
// Safety: never overwrites an existing file; refuses a non-empty target unless
// --adopt is given. No network, no package installs. Node 18+.
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const LOOP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const STARTER = path.join(LOOP_ROOT, 'starter');
const LOOP_VERSION = JSON.parse(fs.readFileSync(path.join(LOOP_ROOT, '.codex-plugin/plugin.json'), 'utf8')).version;
const LOOP_DOCS = ['loop.md', 'ATLAS-FIRST.md', 'OWNER-COMMUNICATION.md', 'EFFICIENT-WORKFLOW.md', 'DELIVERY-WORKFLOW.md', 'SECURITY.md'];

// ── arguments (read in main) ────────────────────────────────────────────────
let argv = [];
let target = '';
let adopt = false;
const flag = name => argv.includes(name);
const option = name => { const i = argv.indexOf(name); return i >= 0 ? argv[i + 1] : undefined; };
const today = new Date().toISOString().slice(0, 10);

// ── helpers ─────────────────────────────────────────────────────────────────
export const slugify = value => String(value).toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 40) || 'item';
const fill = (template, values) => template.replace(/\{\{(\w+)\}\}/g, (_, key) => values[key] ?? '');
const written = [], skipped = [];
function write(relative, content) {
    const full = path.join(target, relative);
    if (fs.existsSync(full)) { skipped.push(relative); return false; }
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
    written.push(relative);
    return true;
}
const copy = (from, to) => write(to, fs.readFileSync(from, 'utf8'));
const run = (cmd, args, opts = {}) => execFileSync(cmd, args, { cwd: target, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], ...opts });

// ── brief ───────────────────────────────────────────────────────────────────
async function askBrief() {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const ask = async (q, d = '') => (await rl.question(d ? `${q} [${d}]: ` : `${q}: `)).trim() || d;
    console.log('Loop starter. Answer in plain words; press Enter to accept a default.\n');
    const brief = {
        name: await ask('Project name'),
        audience: await ask('Who is it for'),
        outcome: await ask('What must the first release do'),
        stack: await ask('Stack (or "to decide")', 'to decide'),
        languages: (await ask('Languages (comma separated)', 'en')).split(',').map(s => s.trim()).filter(Boolean),
        features: []
    };
    console.log('\nFeatures for the first release. Format: Title: step > step > step   (empty line to finish)');
    for (;;) {
        const line = (await rl.question('  feature: ')).trim();
        if (!line) break;
        const [title, steps = ''] = line.split(':');
        brief.features.push({ title: title.trim(), steps: steps.split('>').map(s => s.trim()).filter(Boolean) });
    }
    rl.close();
    return brief;
}

export function normaliseBrief(raw) {
    const brief = { ...raw };
    if (!brief.name) throw new Error('The brief needs a name.');
    brief.slug = brief.slug || slugify(brief.name);
    brief.audience = brief.audience || brief.for || 'to confirm with the owner';
    brief.outcome = brief.outcome || 'to confirm with the owner';
    brief.stack = brief.stack || 'to decide';
    brief.languages = Array.isArray(brief.languages) && brief.languages.length ? brief.languages : ['en'];
    brief.ownerStyle = brief.ownerStyle || 'Simple, plain words and short lines. Lead with the result. Decision-ready work with no placeholders.';
    const used = new Set(['overview', 'roadmap', 'quality-gates']);
    brief.features = (brief.features || []).map((feature, index) => {
        const base = typeof feature === 'string' ? { title: feature } : { ...feature };
        let id = slugify(base.id || base.title || `feature-${index + 1}`);
        while (used.has(id)) id = `${id}-${index + 1}`;
        used.add(id);
        const steps = (base.steps && base.steps.length ? base.steps : ['Start', 'Main action', 'Result']).map(String);
        return { id, title: base.title || id, goal: base.goal || `Deliver ${base.title || id} for ${brief.audience}.`, steps, acceptance: base.acceptance || '', failure: base.failure || '', release: Number(base.release) || 1 };
    });
    if (!brief.features.length) throw new Error('The brief needs at least one feature for the first release.');
    brief.buildOrder = [...brief.features].sort((a, b) => a.release - b.release).map(f => f.id);
    brief.openQuestions = brief.openQuestions || ['Hosting and release target', 'Where user data is stored (if any)', 'Accessibility and device targets', 'Analytics and privacy rules'];
    return brief;
}

// ── atlas plan ──────────────────────────────────────────────────────────────
export function atlasPlan(brief) {
    const chunk = (list, size) => list.reduce((rows, item, i) => { if (i % size === 0) rows.push([]); rows[rows.length - 1].push(item); return rows; }, []);
    const short = (text, max = 58) => (text.length > max ? text.slice(0, max - 1).trimEnd() + '…' : text);
    const overview = {
        id: 'overview', group: 'Start here', title: 'The whole product', status: 'planned',
        subtitle: `${brief.name} for ${brief.audience}. Each feature opens its own map.`,
        source: '',
        rows: [
            [['open', `Open ${brief.name}`, 'Entry point. Design the first screen and how a new user starts.']],
            ...chunk(brief.features.map(f => [`f-${f.id}`, f.title, f.goal]), 3),
            [['outcome', 'First release outcome', brief.outcome]]
        ],
        edges: [...brief.features.map(f => ['open', `f-${f.id}`, 'Choose']), ...brief.features.map(f => [`f-${f.id}`, 'outcome', 'Delivers'])],
        drilldowns: Object.fromEntries(brief.features.map(f => [`f-${f.id}`, f.id])),
        notes: ['Planned from the approved brief. Switch to delivered when the features exist.']
    };
    const releases = [...new Set(brief.features.map(f => f.release))].sort((a, b) => a - b);
    const roadmap = {
        id: 'roadmap', group: 'Start here', title: 'Build order', status: 'planned',
        subtitle: 'The order Loop builds the features in (meta.buildOrder).',
        source: '',
        rows: releases.flatMap(r => chunk(brief.buildOrder.map(id => brief.features.find(f => f.id === id)).filter(f => f.release === r).map(f => [`r-${f.id}`, f.title, `Release ${r}. Track: .loop/tracks/${f.id}/spec.md`]), 3)),
        edges: brief.buildOrder.slice(1).map((id, i) => [`r-${brief.buildOrder[i]}`, `r-${id}`, 'Then']),
        drilldowns: Object.fromEntries(brief.features.map(f => [`r-${f.id}`, f.id])),
        notes: ['npm run atlas:next always names the first map in this order that is not delivered.']
    };
    const quality = {
        id: 'quality-gates', group: 'Systems', title: 'How every feature is built', status: 'delivered',
        subtitle: 'The atlas-first checkpoint loop this project follows.',
        source: 'AGENTS.md:1; .loop/workflow.md:1',
        rows: [
            [['next', 'Pick next map', 'npm run atlas:next names the next planned map and its track.']],
            [['map', 'Make the map exact', 'Steps, branches, defaults, failure paths. Status: building.']],
            [['build', 'Build to the map', 'Smallest coherent change, all languages, version pins.']],
            [['check', 'Check', 'Behaviour tests, npm test, npm run atlas, screenshots for visual work.']],
            [['flip', 'Flip to delivered', 'Add source refs (file:line). The build refuses delivered without source.']],
            [['record', 'Record and report', 'Track, fix queue, HANDOFF CURRENT RESUME, commit, plain-words report.']]
        ],
        edges: [['next', 'map', 'Read'], ['map', 'build', 'Exact'], ['build', 'check', 'Done'], ['check', 'build', 'Fails'], ['check', 'flip', 'Passes'], ['flip', 'record', 'Built'], ['record', 'next', 'Repeat']],
        notes: ['Defined by AGENTS.md and .loop/workflow.md (generated by Loop).']
    };
    const features = brief.features.map(f => {
        const steps = f.steps.map((step, i) => [`s${i + 1}`, short(step), `To build: ${step}. Define the guard, default, exit and failure path before coding.`]);
        const rows = steps.map(step => [step]);
        const edges = steps.slice(1).map((step, i) => [steps[i][0], step[0], 'Next']);
        if (f.failure) { rows[rows.length - 1].push(['fail', 'If it fails', f.failure]); edges.push([steps[steps.length - 1][0], 'fail', 'Error'], ['fail', steps[0][0], 'Retry']); }
        rows.push([['done', 'Works end to end', `Acceptance: ${f.acceptance || f.goal}`]]);
        edges.push([steps[steps.length - 1][0], 'done', 'Complete']);
        return { id: f.id, group: 'Features', title: f.title, status: 'planned', subtitle: f.goal, source: '', rows, edges, notes: [`Planned · release ${f.release} · track .loop/tracks/${f.id}/spec.md`] };
    });
    const meta = {
        title: `${brief.name} · Flow Atlas`, slug: brief.slug, date: today,
        commit: 'initial plan (nothing built yet)',
        scope: `Atlas-first plan for ${brief.name}. First release: ${brief.outcome}`,
        groups: ['Start here', 'Features', 'Systems', 'Supporting pages'],
        featureGroup: 'Features',
        buildOrder: brief.buildOrder
    };
    return { meta, graphs: [overview, roadmap, ...features, quality] };
}

function atlasModule({ meta, graphs }) {
    return `// ${meta.title}. Edit this file; run npm run atlas to rebuild.\n// Status per map: planned → building → delivered (delivered needs source: 'file:line; ...').\n// Method: Loop/ATLAS-FIRST.md\nexport const meta = ${JSON.stringify(meta, null, 2)};\n\nexport const graphs = ${JSON.stringify(graphs, null, 2)};\n`;
}

function trackSpec(brief, f) {
    return `# ${f.title}\n\nStatus: planned · release ${f.release} · map \`${f.id}\` in \`docs/app-map/atlas-data.mjs\`\n\n## Goal\n\n${f.goal}\n\n## Steps (from the map)\n\n${f.steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}${f.failure ? `\n\nIf it fails: ${f.failure}` : ''}\n\n## Acceptance\n\n${f.acceptance || f.goal}\n\n## Done checklist\n\n- [ ] Map made exact before coding (guards, defaults, exits, failure paths); status \`building\`\n- [ ] Built to the map; smallest coherent change\n- [ ] Behaviour tests added and passing (\`npm test\`)\n- [ ] User text in every language: ${brief.languages.join(', ')}\n- [ ] Version pins / caches bumped where served files changed\n- [ ] Map \`delivered\` with \`source\` refs; \`npm run atlas\` passes\n- [ ] Doc or notes updated; FIX-QUEUE and HANDOFF current\n- [ ] Owner shown the result (screenshots for visual work); verified vs not verified stated\n\n## Decisions\n\n- (record owner decisions here with the date)\n`;
}

function briefDoc(brief) {
    return `# ${brief.name} — project brief\n\nApproved ${today}. Source of truth for scope; the atlas shows behaviour.\n\n| | |\n| --- | --- |\n| For | ${brief.audience} |\n| First release must | ${brief.outcome} |\n| Stack | ${brief.stack} |\n| Languages | ${brief.languages.join(', ')} |\n\n## Features (build order)\n\n${brief.buildOrder.map((id, i) => { const f = brief.features.find(x => x.id === id); return `${i + 1}. **${f.title}** (release ${f.release}) — ${f.goal}`; }).join('\n')}\n\n## Constraints\n\n${(brief.constraints || ['(none recorded)']).map(c => `- ${c}`).join('\n')}\n\n## Must not do\n\n${(brief.mustNot || ['(none recorded)']).map(c => `- ${c}`).join('\n')}\n\n## Open questions (ask the owner before they matter)\n\n${brief.openQuestions.map(q => `- ${q}`).join('\n')}\n`;
}

// ── main ────────────────────────────────────────────────────────────────────
async function main() {
    argv = process.argv.slice(2);
    const positional = argv.filter((arg, i) => !arg.startsWith('--') && !['--brief', '--name'].includes(argv[i - 1]));
    if (!positional[0] || flag('--help')) {
        console.log('Usage: node scripts/loop-init.mjs <target> [--brief brief.json] [--git] [--adopt [--name "Name"]]');
        process.exit(positional[0] ? 0 : 2);
    }
    target = path.resolve(positional[0]);
    adopt = flag('--adopt');
    if (fs.existsSync(target) && fs.readdirSync(target).filter(n => n !== '.DS_Store' && n !== '.git').length && !adopt) {
        console.error(`Target is not empty: ${target}\nUse --adopt to add the atlas tools to an existing project (nothing is overwritten).`);
        process.exit(2);
    }
    fs.mkdirSync(target, { recursive: true });

    let brief;
    if (adopt) {
        const name = option('--name') || path.basename(target);
        brief = normaliseBrief({ name, outcome: 'map the current behaviour, then plan new features', features: [{ id: 'current-app', title: 'Current app (to map)', steps: ['Entry points', 'Main screens', 'Data and storage', 'Background work'], goal: 'Map what already exists as delivered maps with source references.' }] });
    } else {
        const raw = option('--brief') ? JSON.parse(fs.readFileSync(path.resolve(option('--brief')), 'utf8')) : await askBrief();
        brief = normaliseBrief(raw);
    }

    // Loop policy copy (project-local, like Lite's Loop/ folder)
    for (const doc of LOOP_DOCS) if (fs.existsSync(path.join(LOOP_ROOT, doc))) copy(path.join(LOOP_ROOT, doc), path.join('Loop', doc));
    write('Loop/README.md', `# Loop (project copy)\n\nCopied from Loop ${LOOP_VERSION} on ${today}. Start with \`../AGENTS.md\`, then \`loop.md\` and \`ATLAS-FIRST.md\`. This copy may be newer or older than the installed Loop plugin; it governs this project.\n`);

    // Atlas tools
    for (const file of ['atlas-template.html', 'build-atlas.mjs', 'atlas-status.mjs', 'verify-atlas.mjs']) copy(path.join(STARTER, 'docs/app-map', file), path.join('docs/app-map', file));
    const plan = atlasPlan(brief);
    write('docs/app-map/atlas-data.mjs', atlasModule(plan));

    const values = {
        name: brief.name, date: today, loopVersion: LOOP_VERSION, outcome: brief.outcome, audience: brief.audience, stack: brief.stack,
        languages: brief.languages.join(', '), ownerStyle: brief.ownerStyle, mapCount: String(plan.graphs.length),
        firstFeature: brief.features.find(f => f.id === brief.buildOrder[0]).title, firstFeatureId: brief.buildOrder[0],
        gitLine: flag('--git') ? 'Local Git repository initialised with the first commit.' : 'Git not initialised by the starter.'
    };
    const tpl = name => fs.readFileSync(path.join(STARTER, 'templates', name), 'utf8');
    write('AGENTS.md', fill(tpl('AGENTS.md'), values));
    write('HANDOFF.md', fill(tpl('HANDOFF.md'), values));
    write('.loop/workflow.md', fill(tpl('workflow.md'), values));
    write('docs/app-map/FIX-QUEUE.md', fill(tpl('FIX-QUEUE.md'), values));
    write('docs/app-map/README.md', fill(tpl('app-map-README.md'), values));
    write('.gitignore', tpl('gitignore'));
    if (!adopt) { write('docs/project-brief.md', briefDoc(brief)); write('docs/project-brief.json', JSON.stringify(brief, null, 2) + '\n'); }
    for (const f of brief.features) write(`.loop/tracks/${f.id}/spec.md`, trackSpec(brief, f));
    copy(path.join(STARTER, 'tests/atlas-contract.test.mjs'), 'tests/atlas-contract.test.mjs');

    const scripts = { atlas: 'node docs/app-map/build-atlas.mjs', 'atlas:status': 'node docs/app-map/atlas-status.mjs', 'atlas:next': 'node docs/app-map/atlas-status.mjs --next', 'atlas:verify': 'node docs/app-map/verify-atlas.mjs', test: 'node --test' };
    const pkgPath = path.join(target, 'package.json');
    if (fs.existsSync(pkgPath)) {
        const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
        pkg.scripts = pkg.scripts || {};
        const added = Object.entries(scripts).filter(([k]) => !(k in pkg.scripts));
        for (const [k, v] of added) pkg.scripts[k] = v;
        if (added.length) { fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n'); written.push(`package.json (added scripts: ${added.map(([k]) => k).join(', ')})`); }
    } else {
        write('package.json', JSON.stringify({ name: brief.slug, version: '0.1.0', private: true, type: 'module', scripts }, null, 2) + '\n');
    }

    // Build and check the atlas right away: the project starts from its map.
    const build = run(process.execPath, ['docs/app-map/build-atlas.mjs']).trim().split('\n').pop();
    let status = '';
    try { status = run(process.execPath, ['docs/app-map/atlas-status.mjs', '--next']); } catch (error) { status = error.stdout || ''; }

    if (flag('--git')) {
        try {
            if (!fs.existsSync(path.join(target, '.git'))) run('git', ['init', '-q']);
            run('git', ['add', '-A']);
            run('git', ['commit', '-q', '-m', `[CP-000] Loop atlas-first project start\n\nCreated by Loop ${LOOP_VERSION} loop-init.mjs from the approved brief.`]);
        } catch (error) {
            console.warn(`Git step skipped: ${(error.stderr || error.message).toString().trim().split('\n')[0]}`);
        }
    }

    console.log(`\nLoop ${LOOP_VERSION} · ${adopt ? 'adopted' : 'created'} ${brief.name} at ${target}`);
    console.log(`Atlas: ${build}`);
    console.log(`Files written: ${written.length}${skipped.length ? ` · kept existing: ${skipped.join(', ')}` : ''}`);
    console.log('\n' + status.trim());
    console.log('\nOpen docs/app-map/index.html to see the plan. Then build the next map (see Loop/ATLAS-FIRST.md).');
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
    main().catch(error => { console.error(error.message); process.exit(1); });
}
