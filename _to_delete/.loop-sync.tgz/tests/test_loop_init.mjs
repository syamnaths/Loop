// Loop starter tests: run with  node --test tests/test_loop_init.mjs
// Creates throwaway projects in the OS temp folder and removes them.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const LOOP = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const INIT = path.join(LOOP, 'scripts/loop-init.mjs');
const BRIEF = path.join(LOOP, 'examples/brief.example.json');
const temp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'loop-init-'));
const node = (args, cwd) => spawnSync(process.execPath, args, { cwd, encoding: 'utf8' });

test('a new project is born from its atlas plan', () => {
    const dir = path.join(temp(), 'calm');
    const result = node([INIT, dir, '--brief', BRIEF]);
    assert.equal(result.status, 0, result.stderr);
    for (const file of ['AGENTS.md', 'HANDOFF.md', '.loop/workflow.md', 'docs/project-brief.md', 'docs/app-map/atlas-data.mjs', 'docs/app-map/index.html', 'docs/app-map/FLOW-REFERENCE.md', 'docs/app-map/CONTROL-INVENTORY.md', 'tests/atlas-contract.test.mjs', 'Loop/loop.md', 'Loop/ATLAS-FIRST.md', 'Loop/OWNER-COMMUNICATION.md', 'package.json']) {
        assert.ok(fs.existsSync(path.join(dir, file)), `${file} exists`);
    }
    for (const id of ['first-open', 'write-today', 'streak', 'daily-reminder']) assert.ok(fs.existsSync(path.join(dir, '.loop/tracks', id, 'spec.md')), `track ${id}`);
    assert.match(result.stdout, /Next: First open \(first-open\)/, 'prints the first feature to build');
    const atlas = JSON.parse(fs.readFileSync(path.join(dir, 'docs/app-map/atlas.json'), 'utf8'));
    assert.deepEqual(atlas.graphs.map(g => g.id).sort(), ['daily-reminder', 'first-open', 'overview', 'quality-gates', 'roadmap', 'streak', 'write-today']);
    assert.deepEqual(atlas.meta.buildOrder, ['first-open', 'write-today', 'streak', 'daily-reminder'], 'release 2 features come last');
    assert.ok(atlas.graphs.filter(g => g.group === 'Features').every(g => g.status === 'planned'));
    const writeToday = atlas.graphs.find(g => g.id === 'write-today');
    assert.ok(writeToday.rows.flat().some(n => n[0] === 'fail'), 'failure path from the brief becomes a branch');
    const handoff = fs.readFileSync(path.join(dir, 'HANDOFF.md'), 'utf8');
    assert.equal((handoff.match(/^## CURRENT RESUME/gm) || []).length, 1);
    assert.match(handoff, /build \*\*First open\*\*/);
    assert.doesNotMatch(fs.readFileSync(path.join(dir, 'AGENTS.md'), 'utf8') + handoff, /\{\{\w+\}\}/, 'no placeholders left');
    // The generated project's own checks pass.
    const tests = node(['--test'], dir);
    assert.equal(tests.status, 0, tests.stdout + tests.stderr);
});

test('a non-empty folder is refused unless adopting, and nothing is overwritten', () => {
    const dir = temp();
    fs.writeFileSync(path.join(dir, 'index.html'), '<p>existing</p>');
    fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: 'old', scripts: { test: 'echo mine' } }));
    const refused = node([INIT, dir, '--brief', BRIEF]);
    assert.equal(refused.status, 2);
    assert.match(refused.stderr, /not empty/);
    const adopted = node([INIT, dir, '--adopt', '--name', 'Old App']);
    assert.equal(adopted.status, 0, adopted.stderr);
    assert.equal(fs.readFileSync(path.join(dir, 'index.html'), 'utf8'), '<p>existing</p>');
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    assert.equal(pkg.scripts.test, 'echo mine', 'existing scripts are kept');
    assert.equal(pkg.scripts.atlas, 'node docs/app-map/build-atlas.mjs', 'atlas scripts are added');
    assert.ok(fs.existsSync(path.join(dir, '.loop/tracks/current-app/spec.md')));
});

test('the atlas refuses a delivered map without real source, and accepts it with source', () => {
    const dir = path.join(temp(), 'p');
    assert.equal(node([INIT, dir, '--brief', BRIEF]).status, 0);
    const dataPath = path.join(dir, 'docs/app-map/atlas-data.mjs');
    const original = fs.readFileSync(dataPath, 'utf8');
    const flip = source => fs.writeFileSync(dataPath, original.replace(/("id": "first-open",[\s\S]*?"status": )"planned"([\s\S]*?"source": )""/, `$1"delivered"$2${JSON.stringify(source)}`));
    flip('');
    let build = node([path.join(dir, 'docs/app-map/build-atlas.mjs')]);
    assert.notEqual(build.status, 0);
    assert.match(build.stderr, /first-open.*needs source references/);
    flip('src/missing.js:1');
    build = node([path.join(dir, 'docs/app-map/build-atlas.mjs')]);
    assert.match(build.stderr, /source not found src\/missing\.js:1/);
    fs.mkdirSync(path.join(dir, 'src'));
    fs.writeFileSync(path.join(dir, 'src/first-open.js'), 'export const ready = true;\n');
    flip('src/first-open.js:1');
    build = node([path.join(dir, 'docs/app-map/build-atlas.mjs')]);
    assert.equal(build.status, 0, build.stderr);
    const next = node([path.join(dir, 'docs/app-map/atlas-status.mjs'), '--next']);
    assert.match(next.stdout, /Next: Write today \(write-today\)/, 'the next map moves on after delivery');
    const status = JSON.parse(node([path.join(dir, 'docs/app-map/atlas-status.mjs'), '--json']).stdout);
    assert.ok(status.delivered.includes('first-open'));
});

test('a broken edge stops the build with a clear message', () => {
    const dir = path.join(temp(), 'q');
    assert.equal(node([INIT, dir, '--brief', BRIEF]).status, 0);
    const dataPath = path.join(dir, 'docs/app-map/atlas-data.mjs');
    fs.writeFileSync(dataPath, fs.readFileSync(dataPath, 'utf8').replace('"Choose"', '"Choose"], ["open", "ghost", "Nowhere"'));
    const build = node([path.join(dir, 'docs/app-map/build-atlas.mjs')]);
    assert.notEqual(build.status, 0);
    assert.match(build.stderr, /broken edge open → ghost/);
});

test('brief rules: a name and at least one feature are required', async () => {
    const { normaliseBrief } = await import(INIT);
    assert.throws(() => normaliseBrief({ features: ['x'] }), /needs a name/);
    assert.throws(() => normaliseBrief({ name: 'X' }), /at least one feature/);
    const brief = normaliseBrief({ name: 'Shop App', features: ['Overview', 'Roadmap', 'Cart'] });
    assert.deepEqual(brief.features.map(f => f.id), ['overview-1', 'roadmap-2', 'cart'], 'feature ids never clash with the overview or roadmap maps');
    assert.equal(brief.slug, 'shop-app');
});
