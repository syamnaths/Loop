# Changelog

## 0.4.0 — atlas-first

- New project starter `scripts/loop-init.mjs` and `starter/`: a project is born from its brief as an atlas plan (overview, roadmap, one map per feature, quality gates), with `AGENTS.md`, a single CURRENT RESUME `HANDOFF.md`, `.loop/workflow.md`, a track per feature, atlas contract tests and npm scripts. `--adopt` adds Loop to an existing project without overwriting anything.
- Atlas tools: `build-atlas.mjs` (validates maps, edges, drilldowns, statuses and real `file:line` sources), `atlas-status.mjs` (`--next`, `--json`), `verify-atlas.mjs` (optional Playwright check), and a generic interactive atlas template.
- `loop.md` rewritten as a short policy with the product rules learned on Lite: one feature = one map + track + test + doc; every language; gender-neutral content; version and cache bumps; measure before claiming; plans are not features; owner-approved pushes.
- New docs: `ATLAS-FIRST.md`, `OWNER-COMMUNICATION.md`, `SECURITY.md` (moved out of `loop.md`), `README.md`.
- `EFFICIENT-WORKFLOW.md` generalised; `DELIVERY-WORKFLOW.md` ties tracks to atlas maps.
- Codex router: `[LOOP_CLASSIFY]` slice so only the relevant part of a long prompt is classified.
- Previous versions of changed files are kept in `archive/v0.3.1/`.
