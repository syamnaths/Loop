# Loop

Loop is a local-first framework for building software with an AI agent and a human owner. From version 0.4 it is **atlas-first**: every project starts from a flow atlas, every feature is built to its map, and a feature is done only when its map is flipped to delivered with real source references.

Loop is **platform-independent**. You choose the platform at the start: web, Android, iPhone/iPad, mobile for both (Flutter, React Native…), desktop, backend/API, command-line/library, other, or several together. The choice shapes the proof ladder, platform rules, version bumps and the release map. The atlas tools need Node 18+ on your machine only.

## Start a new project

1. Write a brief (copy `examples/brief.example.json` for web or `examples/brief.android.example.json` for Android): name, who it is for, what the first release must do, **platforms**, stack, languages, and the features with their steps.
2. Run:

   ```
   node scripts/loop-init.mjs ~/Desktop/Ikigai/my-app --brief my-brief.json --git
   ```

   Without `--brief`, the script asks the questions in the terminal, starting with the platform menu. `--platform android` (or `web,ios`) sets or overrides the platform.
3. Open `my-app/docs/app-map/index.html`. You will see the whole product, the build order, a map per feature (all `planned`), the quality loop and the release path for your platform.
4. In the new project, tell your agent: **"Use Loop for this project. Build the next atlas map."**

What the starter creates:

| Path | Purpose |
| --- | --- |
| `AGENTS.md` | Working agreement every agent reads first |
| `HANDOFF.md` | One `CURRENT RESUME` block: status and the exact next action |
| `.loop/workflow.md`, `.loop/tracks/<map>/spec.md` | Delivery path, modes, and a done-checklist per feature and for release |
| `.loop/platform.md` | Chosen platform: stack, test commands, proof ladder, rules, release path |
| `docs/app-map/` | Atlas data, builder, status, atlas check, interactive `index.html`, fix queue |
| `docs/project-brief.md` | The approved brief and open questions |
| `Loop/` | Project copy of the policy files |
| `package.json` (JavaScript projects only) | `npm run atlas`, `atlas:status`, `atlas:next`, `atlas:check`, `atlas:verify`. Other platforms use `node docs/app-map/...` directly. |

## Add Loop to an existing project

```
node scripts/loop-init.mjs ~/Desktop/Ikigai/existing-app --adopt --name "Existing App" --platform android
```

Without `--platform`, Loop guesses from the files and tells you. Adds the atlas tools, policy copy, tracks and platform notes. **Nothing existing is overwritten.** Then map the current behaviour as delivered maps before planning new features.

## Files in this folder

| File | What it is |
| --- | --- |
| `loop.md` | The core policy (v0.4) |
| `ATLAS-FIRST.md` | Atlas format and the build loop |
| `OWNER-COMMUNICATION.md` | How to talk to the owner |
| `EFFICIENT-WORKFLOW.md` | Bounded context, modes, cost honesty |
| `DELIVERY-WORKFLOW.md` | Tracks, reviews, debugging, release |
| `SECURITY.md` | Security verification standard |
| `MODEL-ROUTING.md`, `LOCAL-MODEL-ROUTING.md`, `config/`, `scripts/codex_model_router.py` | Optional model routing |
| `scripts/loop-init.mjs`, `starter/` | The atlas-first project starter (`starter/platforms.mjs` holds the platform profiles) |
| `examples/` | Example briefs for a web app and an Android app |
| `tests/` | Checks for the router, policy wiring and the starter |
| `archive/v0.3.1/` | The previous versions of changed files |
| `CHANGELOG.md` | What changed in each version |

## Check Loop itself

```
node --test tests/test_loop_init.mjs
python3 -m unittest tests/test_codex_model_router.py tests/test_efficiency_contract.py
```

Install as a Codex plugin: see `INSTALL.md`.
